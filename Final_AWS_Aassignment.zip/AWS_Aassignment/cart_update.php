<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(403); // Forbidden
    echo "Not logged in.";
    exit();
}

$user_id = $_SESSION['user_id'];
$product_id = $_POST['product_id'] ?? '';
$quantity = $_POST['quantity'] ?? 1;

if (!$product_id || !is_numeric($quantity) || $quantity < 1) {
    http_response_code(400); // Bad request
    echo "Invalid input.";
    exit();
}

// Update quantity in cart
$sql = "UPDATE cart SET cart_quantity = ? WHERE user_id = ? AND product_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iss", $quantity, $user_id, $product_id);

if ($stmt->execute()) {
    echo "Quantity updated.";
} else {
    http_response_code(500); // Server error
    echo "Database error.";
}
?>
