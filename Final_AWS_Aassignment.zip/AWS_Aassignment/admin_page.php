<?php
include 'header.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 1) {
    header("Location: login.php");
    exit();
}
include 'db_connect.php';

$result = $conn->query("SELECT * FROM products");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin - Manage Products</title>
    <link rel="stylesheet" href="admin_styles.css">
    <style>
        table td {
            border-bottom: black 1px solid;
            border-top: black 1px solid;
            line-height: 2.5;
        }

        /* Lightsalmon button styles */
        .btn-lightsalmon {
            background-color: lightsalmon;
            color: white;
            border: none;
            padding: 12px 16px;
            font-size: 14px;
            border-radius: 5px;
            text-decoration: none;
            transition: 0.2s;
            display: inline-block;
        }

        .btn-lightsalmon:hover {
            background-color: #f08060;
            transform: scale(1.05);
            color: white;
        }

        /* Base button style */
        .btn-custom {
            color: white;
            padding: 2px 12px;
            font-size: 14px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            transition: 0.2s;
        }

        /* Add button (lightsalmon) */
        .btn-add {
            background-color: lightsalmon;
        }

        .btn-add:hover {
            background-color: #f08060;
        }

        /* Edit button (deepskyblue) */
        .btn-edit {
            background-color: deepskyblue;
        }

        .btn-edit:hover {
            background-color: #00a3dd;
        }

        /* Delete button (crimson) */
        .btn-delete {
            background-color: crimson;
        }

        .btn-delete:hover {
            background-color: #b30000;
        }
    </style>
</head>
<body>

<h2 style="text-align:center; margin-bottom: 10px;">Admin - Manage Products</h2>

<div style="text-align:center; margin-top: 10px; margin-bottom: 20px;">
    <a href="add_product.php" class="btn-lightsalmon"><b>Add New Product</b></a>
</div>

<table class="table table-bordered" style="width:80%; margin: auto;">
    <thead>
        <tr>
            <th><strong>ID</strong></th>
            <th><strong>Name</strong></th>
            <th><strong>Price</strong></th>
            <th><strong>Quantity</strong></th>
            <th><strong>Category</strong></th>
            <th><strong>Description</strong></th>
            <th><strong>Image</strong></th>
            <th><strong>Actions</strong></th>
        </tr>
    </thead>
    <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['product_id'] ?></td>
            <td><?= $row['product_name'] ?></td>
            <td style="text-align: center;"><?= $row['product_price'] ?></td>
            <td style="text-align: center;"><?= $row['quantity'] ?></td>
            <td style="text-align: center;"><?= $row['category_id'] ?></td>
            <td><?= implode(' ', array_slice(explode(' ', $row['description']), 0, 5)) . '...' ?></td>
            <td><img src="image/<?= $row['image'] ?>" width="100px"></td>
            <td>
                <a href="edit_product.php?id=<?= $row['product_id'] ?>" class="btn-custom btn-edit">Edit</a>
                <a href="delete_product.php?id=<?= $row['product_id'] ?>" class="btn-custom btn-delete" onclick="return confirm('Delete this product?')">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<?php include 'footer.php'; ?>
</body>
</html>
