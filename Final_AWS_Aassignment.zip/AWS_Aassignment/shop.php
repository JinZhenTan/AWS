<?php
include 'header.php';
include 'db_connect.php';

// Handle Add to Cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    if (!isset($_SESSION['user_id'])) {
        echo "<script>
            alert('You must login to add items to your cart.');
            window.location.href = 'login.php';
        </script>";
        exit();
    }

    $user_id = $_SESSION['user_id'];
    $product_id = $_POST['product_id'];
    $quantity = 1;

    // cart_id is user_id + '_cart'
    $cart_id = $user_id;

    // Check if product is already in cart
    $check = $conn->prepare("SELECT * FROM cart WHERE user_id = ? AND product_id = ?");
    $check->bind_param("ss", $user_id, $product_id);
    $check->execute();
    $checkResult = $check->get_result();

    if ($checkResult->num_rows === 0) {
        $insert = $conn->prepare("INSERT INTO cart (cart_id, user_id, product_id, cart_quantity) VALUES (?, ?, ?, ?)");
        $insert->bind_param("sssi", $cart_id, $user_id, $product_id, $quantity);
        $insert->execute();
    } else {
        $update = $conn->prepare("UPDATE cart SET cart_quantity = cart_quantity + 1 WHERE user_id = ? AND product_id = ?");
        $update->bind_param("ss", $user_id, $product_id);
        $update->execute();
    }

    echo "<script>alert('Product added to cart.');</script>";
}

// Pagination setup
$limit = 9;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Category filter
$category = isset($_GET['category']) ? $_GET['category'] : "";

if (!empty($category)) {
    $stmt = $conn->prepare("SELECT * FROM products WHERE category_id = ? LIMIT ?, ?");
    $stmt->bind_param("sii", $category, $start, $limit);
} else {
    $stmt = $conn->prepare("SELECT * FROM products LIMIT ?, ?");
    $stmt->bind_param("ii", $start, $limit);
}

$stmt->execute();
$result = $stmt->get_result();

if (!empty($category)) {
    $totalQuery = $conn->prepare("SELECT COUNT(*) as total FROM products WHERE category_id = ?");
    $totalQuery->bind_param("s", $category);
} else {
    $totalQuery = $conn->prepare("SELECT COUNT(*) as total FROM products");
}

$totalQuery->execute();
$totalResult = $totalQuery->get_result()->fetch_assoc();
$totalPages = ceil($totalResult['total'] / $limit);

$categories = $conn->query("SELECT category_id FROM categories");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Shop | The Cap Conner</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <style>
        .top-bar {
            display: flex;
            justify-content: space-between;
            margin: 0 10%;
            align-items: center;
        }
        .product-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: flex-start;
            margin: 0 10%;
        }
        @media (max-width: 768px) {
            .product-grid {
                margin: 0 5%;
            }
        }
        .product-card {
            flex: 0 0 calc(33.33% - 20px);
            box-shadow: 0 0 10px #ccc;
            border-radius: 8px;
            padding: 15px;
            background-color: #fff;
            box-sizing: border-box;
            text-align: center;
        }
        .product-card img {
            max-width: 100%;
            height: 200px;
            object-fit: contain;
        }
        .pagination {
            margin-top: 20px;
            display: flex;
            justify-content: center;
        }
        .pagination a {
            margin: 0 5px;
            padding: 8px 12px;
            background-color: lightsalmon;
            color: white;
            border-radius: 5px;
            text-decoration: none;
        }
        .pagination a.active {
            background-color: #e67e22;
        }
        .category-filter {
            margin: 20px 0;
        }
        .category-filter select {
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .product-name {
            font-size: 18px;
            font-weight: bold;
            margin: 10px 0;
        }
        .product-price {
            color: #e67e22;
            font-size: 16px;
            margin-bottom: 10px;
        }
        .add-to-cart-btn {
            background-color: lightsalmon;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 5px;
            cursor: pointer;
        }
        .add-to-cart-btn:hover {
            background-color: #e97b5b;
        }
        
        html, body {
    height: 100%;
    margin: 0;
    display: flex;
    flex-direction: column;
}



footer {
    margin-top: auto;
}
    </style>
</head>
<body>
<div class="container mt-4">
    <div class="top-bar">
        <h2 class="mb-3">Shop</h2>
        <form class="category-filter" method="get" action="shop.php">
            <label for="category">Filter by category:</label>
            <select name="category" onchange="this.form.submit()">
                <option value="">All</option>
                <?php while ($cat = $categories->fetch_assoc()): ?>
                    <option value="<?= htmlspecialchars($cat['category_id']) ?>" <?= $category == $cat['category_id'] ? 'selected' : '' ?>>
                        <?= ucwords(str_replace('_', ' ', htmlspecialchars($cat['category_id']))) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </form>
    </div>

    <div class="product-grid">
        <?php while ($row = $result->fetch_assoc()): ?>
    <div class="product-card">
        <img src="image/<?= htmlspecialchars($row['image']) ?>" alt="<?= htmlspecialchars($row['product_name']) ?>">
        <div class="product-name"><?= htmlspecialchars($row['product_name']) ?></div>
        <div class="product-price">RM <?= number_format($row['product_price'], 2) ?></div>
        <div style="display: flex; justify-content: center; gap: 10px;">
            <a href="product_details.php?id=<?= urlencode($row['product_id']) ?>">
                <button class="add-to-cart-btn">View</button>
            </a>

            <?php if (!isset($_SESSION['role']) || $_SESSION['role'] != 1): ?>
                <form method="post" action="">
                    <input type="hidden" name="product_id" value="<?= htmlspecialchars($row['product_id']) ?>">
                    <button type="submit" name="add_to_cart" class="add-to-cart-btn">Add to Cart</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
<?php endwhile; ?>

    </div>

    <div class="pagination">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <a href="?page=<?= $i ?><?= $category ? '&category=' . urlencode($category) : '' ?>" class="<?= $page == $i ? 'active' : '' ?>">
                <?= $i ?>
            </a>
        <?php endfor; ?>
    </div>
</div>
    <br/>
    <footer><?php include 'footer.php'; ?>   </footer>
</body>
</html>
