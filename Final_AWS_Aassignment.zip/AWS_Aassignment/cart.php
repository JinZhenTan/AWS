<?php
include 'header.php';
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    echo "<script>
        alert('You must login to view your cart.');
        window.location.href = 'login.php';
    </script>";
    exit();
}

$user_id = $_SESSION['user_id'];
$cart_id = $user_id;

$sql = "SELECT c.cart_id, c.product_id, c.cart_quantity, p.product_name, p.product_price, p.image, p.quantity
        FROM cart c 
        JOIN products p ON c.product_id = p.product_id 
        WHERE c.user_id = ? AND c.cart_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $user_id, $cart_id);
$stmt->execute();
$result = $stmt->get_result();

$cart_items = [];
$grand_total = 0;

while ($row = $result->fetch_assoc()) {
    $row['total_price'] = $row['product_price'] * $row['cart_quantity'];
    $grand_total += $row['total_price'];
    $cart_items[] = $row;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Your Cart | The Cap Conner</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<style>
/* Preserved CSS */
.container {
    background-color: #f5f5f5;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
    margin-left:10%;
    margin-right:10%;
    margin-top:20px;
}
h2 {
    font-weight: bold;
    color: #333;
    margin-bottom: 30px;
}
table.table {
    border-collapse: collapse;
    width: 100%;
}
.table thead th {
    background-color: #f2f2f2;
    font-weight: bold;
    text-align: center;
}
.table td, .table th {
    vertical-align: middle !important;
    text-align: center;
}
.cart-image {
    width: 80px;
    height: 80px;
    object-fit: contain;
    border-radius: 5px;
    border: 1px solid #ccc;
}
input[type="number"] {
    width: 80px;
    margin: auto;
    border-radius: 5px;
    border: 1px solid #ccc;
    padding: 5px;
}
.btn-sm {
    font-size: 0.85rem;
}
.btn-primary, .btn-secondary, .btn-success, .btn-danger {
    border-radius: 5px;
    padding: 6px 12px;
    margin: 0 10px;
    font-weight: 500;
    transition: transform 0.2s ease-in-out;
    display: inline-block;
}
.btn-primary:hover, .btn-secondary:hover, .btn-success:hover, .btn-danger:hover {
    transform: scale(1.1);
}
.btn-primary {
    background-color: #3498db;
    border-color: #3498db;
}
.btn-secondary {
    background-color: #7f8c8d;
    border-color: #7f8c8d;
}
.btn-success {
    background-color: lightsalmon;
    border-color: lightsalmon;
}
.btn-danger {
    background-color: #e74c3c;
    border-color: #e74c3c;
}
.d-flex {
    flex-wrap: wrap;
}
.alert-info {
    background-color: #ecf0f1;
    border-color: #bdc3c7;
    color: #2c3e50;
}
@media (max-width: 768px) {
    .cart-image {
        width: 60px;
        height: 60px;
    }
    input[type="number"] {
        width: 60px;
    }
    .btn {
        margin-top: 5px;
    }
}
.continue-shop {
    text-decoration: none;
    font-size: 18px;
    color: blue;
}
.total-price {
    font-size: 24px;
    font-weight: bold;
    color: #2c3e50;
    margin-left: 10%;
    width: 100%;
}
a {
    text-decoration: none;
    color: white;
    transition: 0.2s;
}
a:hover {
    opacity: 0.90;
}
.btn-primary {
    cursor: pointer;
    color: white;
    border: none;
    font-size: 16px; 
}
.btn-primary:hover {
    opacity: 0.9;
}
.cart-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    margin-top: 20px;
}
</style>

<script>
$(document).ready(function() {
    $('input[name^="qty"]').on('input', function() {
        let product_id = $(this).attr('name').match(/\[(.*?)\]/)[1];
        let new_qty = $(this).val();

        if (new_qty < 1) {
            new_qty = 1;
            $(this).val(1);
        }

        $.ajax({
            url: 'cart_update.php',
            method: 'POST',
            data: {
                product_id: product_id,
                quantity: new_qty
            },
            success: function(response) {
                location.reload(); // reload to reflect changes
            },
            error: function() {
                alert("Failed to update quantity. Try again.");
            }
        });
    });
});
</script>

</head>
<body>

<div class="container mt-5">
    <h2 class="mb-4">Your Shopping Cart</h2>

    <?php if (empty($cart_items)): ?>
        <div class="alert alert-info"><p>Your cart is empty. <a href="shop.php" class="continue-shop">Continue shopping</a>.</p></div>
    <?php else: ?>
        <table class="table table-bordered align-middle text-center">
            <thead class="table-light">
                <tr>
                    <th>Image</th>
                    <th>Product</th>
                    <th>Price (RM)</th>
                    <th>Quantity</th>
                    <th>In Stock</th>
                    <th>Total (RM)</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cart_items as $item): ?>
                    <tr>
                        <td><img src="image/<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['product_name']) ?>" class="cart-image"></td>
                        <td><?= htmlspecialchars($item['product_name']) ?></td>
                        <td><?= number_format($item['product_price'], 2) ?></td>
                        <td>
                            <input type="number" name="qty[<?= $item['product_id'] ?>]" value="<?= $item['cart_quantity'] ?>" min="1" max="<?= $item['quantity'] ?>" class="form-control" style="width: 80px; margin: auto;">
                        </td>
                        <td><?= htmlspecialchars($item['quantity']) ?></td>
                        <td><?= number_format($item['total_price'], 2) ?></td>
                        <td>
                            <a href="remove_from_cart.php?id=<?= urlencode($item['product_id']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to remove this item from the cart?');">Remove</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="cart-actions">
            <div>
                <h4 class="total-price">Total: RM <?= number_format($grand_total, 2) ?></h4>
            </div>
            <div>
                <a href="shop.php" class="btn btn-secondary">Continue Shopping</a>
                <a href="checkOut.php" class="btn btn-success">Checkout</a>
            </div>
        </div>
    <?php endif; ?>
</div>

<footer><?php include 'footer.php'; ?></footer>
</body>
</html>
