<?php
include 'header.php';
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['product_id'];
    $password = $_POST['password'];
    $admin_id = $_SESSION['user_id'];

    // Get plain text admin password from database
    $result = $conn->query("SELECT password FROM users WHERE user_id = '$admin_id'");

    if ($result && $result->num_rows > 0) {
        $db_password = $result->fetch_assoc()['password'];

        // Direct string comparison since password is not hashed
        if ($password === $db_password) {
            $conn->query("DELETE FROM products WHERE product_id = '$id'");
            header("Location: admin_page.php");
            exit();
        } else {
            echo "<script>alert('Incorrect password');history.back();</script>";
        }
    } else {
        echo "<script>alert('Admin user not found');history.back();</script>";
    }
    exit();
}

$id = $_GET['id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title >Delete Product</title>
    <link rel="stylesheet" href="admin_styles.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<h2>Confirm Deletion</h2>
<form method="post" class="confirm-delete">
    <input type="hidden" name="product_id" value="<?= $id ?>">
    <div>
        <label>Enter your password to confirm deletion:</label>
        <input type="password" name="password" required class="form-control">
    </div>
    <div style="margin-top:10px;">
        <button class="btn btn-danger">Delete</button>
    </div>
</form>

<?php include 'footer.php'; ?>
</body>
</html>
