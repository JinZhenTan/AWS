<?php
include 'header.php';
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f7fc;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 40%;
            margin: auto;
            background: #fff;
            padding: 40px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin-top: 30px;
            margin-bottom: 30px;
        }

        h2 {
            font-size: 1.8em;
            margin-bottom: 20px;
            text-align: center;
            color: #333;
        }

        label {
            font-size: 1.1em;
            margin-top: 20px;
            color: #333;
            display: block;
        }

        input {
            width: 100%;
            padding: 12px 15px;
            margin-top: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 1em;
            box-sizing: border-box;
        }

        input:focus {
            border-color: #4CAF50;
            outline: none;
        }

        button {
            width: 100%;
            padding: 15px;
            background-color: lightsalmon;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 1.2em;
            cursor: pointer;
            margin-top: 20px;
            transition: 0.2s;
        }

        button:hover {
            opacity: 0.9;
        }

        .payment-methods {
            display: flex;
            justify-content: space-between;
            margin-top: 15px;
        }

        .payment-methods img {
            width: 40px;
            height: auto;
        }

        .error {
            color: red;
            font-size: 0.9em;
            margin-top: 10px;
        }

        .form-group {
            margin-bottom: 20px;
        }


    </style>
    <script>
        function validateForm() {
            // Validate card number (16 digits)
            var cardNumber = document.getElementById("card_number").value;
            if (!/^\d{16}$/.test(cardNumber)) {
                alert("Card number must be 16 digits.");
                return false;
            }

            // Validate expiry date (MM/YY format)
            var expiry = document.getElementById("expiry").value;
            if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(expiry)) {
                alert("Expiry date must be in MM/YY format.");
                return false;
            }

            // Validate CVV (3 or 4 digits)
            var cvv = document.getElementById("cvv").value.trim();
            if (!/^\d{3,4}$/.test(cvv)) {
                alert("Please enter a valid CVV (3 or 4 digits).");
                return false;
            }

            return true;
        }
    </script>
</head>
<body>

<div class="container">
    <h2>Card Payment Checkout</h2>
    <form action="success.php" method="post" onsubmit="return validateForm()">
        <div class="form-group">
            <label for="card_name">Cardholder Name:</label>
            <input type="text" name="card_name" id="card_name" required>
        </div>

        <div class="form-group">
            <label for="card_number">Card Number:</label>
            <input type="text" name="card_number" id="card_number" maxlength="16" required>
        </div>

        <div class="form-group">
            <label for="expiry">Expiry Date (MM/YY):</label>
            <input type="text" name="expiry" id="expiry" placeholder="MM/YY" required>
        </div>

        <div class="form-group">
            <label for="cvv">CVV:</label>
            <input type="text" name="cvv" id="cvv" maxlength="4" inputmode="numeric" pattern="\d{3,4}" required>

        </div>

        <button type="submit">Pay Now</button>

        <div class="payment-methods">
            <img src="image/visa.png" alt="Visa">
            <img src="image/mastercard.png" alt="MasterCard">
            <img src="image/paypal.png" alt="PayPal">
        </div>
    </form>
</div>
    <footer><?php include 'footer.php'; ?></footer>
</body>
</html>
