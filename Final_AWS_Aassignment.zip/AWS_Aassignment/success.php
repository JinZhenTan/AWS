<?php
session_start();
include 'db_connect.php';

$user_id = $_SESSION['user_id'] ?? null;

if (!$user_id) {
    header("Location: login.php");
    exit();
}

// Generate payment ID
$payment_id = 'PAY' . date('YmdHis');

// Get the last history_id for this user
$stmt = $conn->prepare("
    SELECT history_id 
    FROM history 
    WHERE user_id = ? 
    ORDER BY history_id DESC 
    LIMIT 1
");
$stmt->bind_param("s", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$last_id_row = $result->fetch_assoc();

if ($last_id_row) {
    $last_id = $last_id_row['history_id'];
    $last_num = (int)substr($last_id, 4);
    $new_num = $last_num + 1;
} else {
    $new_num = 1;
}
$history_id = 'HIST' . str_pad($new_num, 3, '0', STR_PAD_LEFT);

// Fetch user's cart items
$stmt = $conn->prepare("
    SELECT c.product_id, c.cart_quantity, p.product_price 
    FROM cart c 
    JOIN products p ON c.product_id = p.product_id 
    WHERE c.user_id = ?
");
$stmt->bind_param("s", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Your cart is already empty or payment session is invalid.";
    exit();
}

// Insert items into history and calculate total
$insert_stmt = $conn->prepare("
    INSERT INTO history (history_id, user_id, history_product_id, history_product_quantity) 
    VALUES (?, ?, ?, ?)
");

$total_amount = 0;

while ($row = $result->fetch_assoc()) {
    $subtotal = $row['product_price'] * $row['cart_quantity'];
    $total_amount += $subtotal;

    $insert_stmt->bind_param("sssi", $history_id, $user_id, $row['product_id'], $row['cart_quantity']);
    $insert_stmt->execute();

    // Update product quantity
    $update_qty_stmt = $conn->prepare("
        UPDATE products 
        SET quantity = quantity - ? 
        WHERE product_id = ?
    ");
    $update_qty_stmt->bind_param("is", $row['cart_quantity'], $row['product_id']);
    $update_qty_stmt->execute();
}


// Insert into payments table (now including payment_date)
$payment_stmt = $conn->prepare("
    INSERT INTO payments (payment_id, user_id, amount, payment_date) 
    VALUES (?, ?, ?, NOW())
");
$payment_stmt->bind_param("ssd", $payment_id, $user_id, $total_amount);
$payment_stmt->execute();

// Clear cart
$clear_stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
$clear_stmt->bind_param("s", $user_id);
$clear_stmt->execute();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Payment Successful</title>
    <style>
        body {
            font-family: Arial;
            text-align: center;
            padding: 50px;
        }
        .message {
            font-size: 1.5em;
            color: green;
        }
        a {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 6px;
        }
    </style>
</head>
<body>
    <div class="message">
        <h1>Thank you! Your payment was successful.</h1>
        <p>Your order has been recorded.</p>
        <p><strong>Order ID:</strong> <?= htmlspecialchars($history_id) ?></p>
        <p><strong>Payment ID:</strong> <?= htmlspecialchars($payment_id) ?></p>
        <p><strong>Total Paid:</strong> RM<?= number_format($total_amount, 2) ?></p>
        <a href="profile.php">Go to Your Profile</a>
    </div>
</body>
</html>
