<?php
include 'header.php';
include 'db_connect.php'; // Make sure this connects to your database
?>

<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <style>

        .hero {
            width: 100%;
            height: 50vh;
            position: relative;
            margin: auto;
        }

        .hero img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: opacity 0.5s ease-in-out;
        }

        .featured {
            padding: 40px 80px;
            text-align: center;
        }

        .featured-products,
        .teasers {
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
            margin-top: 30px;
        }

        .product-card, .teaser-card {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
 
            padding: 15px;
            text-align: center;
        }

        .product-card img, .teaser-card img {
            width: 100%;
            height: 150px;
            object-fit: cover;
        }

        .btn {
            background-color: lightsalmon;
            color: white;
            border: none;
            padding: 10px 20px;
            margin-top: 10px;
            cursor: pointer;
            border-radius: 4px;
            transition: 0.2s;
        }

        .btn:hover {
            opacity: 0.9;
            transform: scale(1.1);
        }

        .about {
            background-color: #f0f0f0;
            padding: 50px 80px;
            text-align: center;
        }

        /* Teasers section for the 3 products */
        .teasers {
            padding: 50px 80px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 30px;
        }

        /* Add some more styles as needed */
    </style>
</head>
<body>

<!-- Hero Section -->
<div class="hero">
    <img id="hero-slideshow" src="image/graduate7.jpg" alt="Hero Slideshow">
</div>

<script>
    const heroImages = [
        "image/graduate1.jpg",
        "image/graduate2.jpg",
        "image/graduate3.jpg",
        "image/graduate4.jpg",
        "image/graduate5.jpg",
        "image/graduate6.jpg",
        "image/graduate7.jpg"
    ];
    let heroIndex = 0;
    const heroSlideshow = document.getElementById("hero-slideshow");

    setInterval(() => {
        heroIndex = (heroIndex + 1) % heroImages.length;
        heroSlideshow.style.opacity = 0;
        setTimeout(() => {
            heroSlideshow.src = heroImages[heroIndex];
            heroSlideshow.style.opacity = 1;
        }, 500);
    }, 4000);
</script>

<!-- Featured Products Section -->
<div class="featured">
    <h2>Featured Products</h2>
    <div class="featured-products">
        <?php
        // Fetch 3 featured products from products table
        $query = "SELECT * FROM products LIMIT 3";
        $result = mysqli_query($conn, $query);

        while ($row = mysqli_fetch_assoc($result)) {
            echo '<div class="product-card">';
            echo '<img src="image/' . htmlspecialchars($row['image']) . '" alt="' . htmlspecialchars($row['product_name']) . '">';
            echo '<p>' . htmlspecialchars($row['product_name']) . '</p>';
            echo '</div>';
        }
        ?>
    </div>
    <br>
    <a href="shop.php"><button class="btn">Explore Now</button></a>
</div>

<!-- About Us Section -->
<div class="about">
    <h2>About Us</h2>
    <p>We are dedicated to offering the best products at the most affordable prices. Our team works hard to ensure quality and satisfaction in every order. Thank you for choosing us!</p>
</div>

<!-- Teaser Products Section -->
<div class="teasers">
    <?php
    // Fetch 3 teaser products from products table
    $query = "SELECT * FROM products ORDER BY product_id DESC LIMIT 3;
";
    $result = mysqli_query($conn, $query);

    while ($row = mysqli_fetch_assoc($result)) {
        echo '<div class="teaser-card">';
        echo '<img src="image/' . htmlspecialchars($row['image']) . '" alt="' . htmlspecialchars($row['product_name']) . '">';
        echo '<a href="shop.php"><button class="btn">Shop Now</button></a>';
        echo '</div>';
    }
    ?>
</div>

<?php include 'footer.php'; ?>

</body>
</html>
