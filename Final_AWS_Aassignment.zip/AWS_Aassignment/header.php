<?php
session_start();
include 'db_connect.php';
?>

<!DOCTYPE html>
<html>
<head>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        /* Same style as your original pasted code */
        html {
            font-family: sans-serif;
            background: #fafafa;
            height: 100%;
            margin: 0;
            display: flex;
            flex-direction: column;
        }

        body {
            margin: 0;
            padding: 0;
            max-width: 100%;
            height: 100%;
            background-color: #fafafa;
            display: flex;
            flex-direction: column;
        }
        footer {
            margin-top: auto;
        }

        .header {
            width: 100%;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #f5f5f5;
            padding: 0px 120px;
            box-sizing: border-box;
        }

        .logo {
            width: 100px;
            cursor: pointer;
        }

        .logo-div,
        .website-div,
        .login-div {
            display: flex;
            align-items: center;
        }

        .website {
            padding: 5px;
            margin-left: 20px;
            text-decoration: none;
            transition: 0.2s;
            font-size: 15px;
            color: #212529;
        }

        .website:hover {
            color: lightsalmon;
            transform: scale(1.2);
            border-bottom: lightsalmon 3px solid;
        }

        .login, .logout {
            text-decoration: none;
            border: 1px lightsalmon solid;
            border-radius: 35px;
            padding: 8px;
            color: white;
            background: lightsalmon;
            transition: 0.2s;
            font-size: 16px;
            margin-left: 10px;
        }

        .login:hover, .logout:hover {
            opacity: 0.95;
            transform: scale(1.1);
            text-decoration: none;
            color: white;
        }

        .cart {
            color: black;
            font-size: 25px;
            margin-right: 15px;
            transition: 0.2s;
        }

        .cart:hover,.profile:hover {
            color: lightsalmon;
            transform: scale(1.2);
        }

        .user-icon {
            font-size: 25px;
            margin-right: 10px;
            color: black;
            transition: 0.2s;
            cursor: pointer;
        }

        .user-icon:hover{
            color: lightsalmon;
            transform: scale(1.2);
        }
        .profile{
            display: inline-block;
        }
    </style>
</head>
<body>

<header>
    <div class="header">
        <div class="logo-div">
            <a href="index.php"><img src="image/logo.png" class="logo"></a>
        </div>

        <div class="website-div">
            <a class="website" href="index.php"><strong>Home</strong></a>
            <a class="website" href="shop.php"><strong>Shop</strong></a>
            <a class="website" href="about.php"><strong>About</strong></a>

            <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 1): ?>
                <!-- Admin link -->
                <a class="website" href="admin_page.php"><strong>Edit Products</strong></a>
            <?php endif; ?>
        </div>

        <div class="login-div">
            <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] != 1): ?>
                <!-- Only show cart and profile if the user is not an admin -->
                <a href="cart.php" class="cart bi bi-cart"></a>
                <a href="profile.php" class="profile"><i class="bi bi-person-circle user-icon"></i></a>
            <?php endif; ?>

            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="logout.php" class="logout">Logout</a>
            <?php else: ?>
                <a href="login.php" class="login">Login / Sign Up</a>
            <?php endif; ?>
        </div>
    </div>
</header>

</body>
</html>
